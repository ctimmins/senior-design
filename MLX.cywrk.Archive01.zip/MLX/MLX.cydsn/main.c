/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <math.h>
int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    I2C_1_Start();
    LCD_Char_1_Start();
    
    //Wait for POR(Power on Reset) release
    CyDelay(10);
    
    //Read the whole EEPROM
    
    
    int i;
    uint8 EEPROM_data[256] = {0};
    I2C_1_MasterSendStart(0x50,0);
    I2C_1_MasterWriteByte(0x00);
    I2C_1_MasterSendRestart(0x50,1);
    for(i = 0;i != 255; i++){
    EEPROM_data[i] = I2C_1_MasterReadByte(1);   
    }
    I2C_1_MasterSendStop();
    
    
    //Write the oscillator trimming value
    /*
    uint8 EEPROM_extraction = EEPROM_data[0xF7];
    uint8 Slave_Addr_Osc = 0x60;
    uint8 Write_Buffer_Osc[5] = {0x04, EEPROM_extraction - 0xAA, EEPROM_extraction, 0x56, 0x00};
    I2C_1_MasterWriteBuf(Slave_Addr_Osc, Write_Buffer_Osc, 5, I2C_1_MODE_COMPLETE_XFER);
    */
    
    //Write configuration value
    /*Default values. Not from EEPROM value*/
    
    I2C_1_MasterSendStart(0x60,0);
    I2C_1_MasterWriteByte(0x03);
    I2C_1_MasterWriteByte(0xB9);
    I2C_1_MasterWriteByte(0x0E);
    I2C_1_MasterWriteByte(0x1F);
    I2C_1_MasterWriteByte(0x74);   
    I2C_1_MasterSendStop();
    
    //Read configuration register and oscillator trimming register
    /*
    uint8 ConfigReadBuf[2] = {0};
    I2C_1_MasterSendStart(0x60,0);
    I2C_1_MasterWriteByte(0x02);
    I2C_1_MasterWriteByte(0x92);
    I2C_1_MasterWriteByte(0x00);
    I2C_1_MasterWriteByte(0x01);
    I2C_1_MasterSendRestart(0x60,1);
    ConfigReadBuf[0] = I2C_1_MasterReadByte(1);
    ConfigReadBuf[1] = I2C_1_MasterReadByte(1);
    I2C_1_MasterSendStop();
    uint16 ConfigSettings = (ConfigReadBuf[1] << 8) | ConfigReadBuf[0];
    */
    
   
    
    
    //Temperature Read(PTAT)
    uint8 Write_Buffer_PTAT[4] = {0x02, 0x90, 0x00,0x01};
    uint8 PTAT[2] = {0};
    
    
    I2C_1_MasterSendStart(0x60,0);
    int x;
    for(x = 0; x != 4; x++){
        I2C_1_MasterWriteByte(Write_Buffer_PTAT[x]);
    }
    I2C_1_MasterSendRestart(0x60,1);
    PTAT[0] = I2C_1_MasterReadByte(1);
    PTAT[1] = I2C_1_MasterReadByte(1);
    I2C_1_MasterSendStop();
    uint16 PTAT_data = (PTAT[1] << 8) | PTAT[0];
   /*
    double VthL = EEPROM_data[0xDA];
    double VthH = EEPROM_data[0xDB];
    double kT1L = EEPROM_data[0xDC];
    double kT1H = EEPROM_data[0xDD];
    double kT2L = EEPROM_data[0xDE];
    double kT2H = EEPROM_data[0xDF];

    double Vth25 = 256 + (VthH/100) + (VthL);
    double Kt1 = (256 + (kT1H/100) + kT1L)/pow(2,10);
    double Kt2 = (256 + (kT2H/100) + kT2L)/pow(2,10);
    
    double Ta = -1*Kt1 + sqrt((Kt1*Kt1)-4*Kt2*(Vth25-PTAT_data]
    
    //Display Value of EEPROM on LCD screen
    LCD_Char_1_ClearDisplay();
    LCD_Char_1_PrintInt16(PTAT_data);

  */  
    
    
    //Whole frame read
    //uint8 Write_Buffer_Frame[4] = {0x02, 0x00,0x01,0x40};
    uint8 IRData[0x40] = {0};
    //I2C_1_MasterWriteBuf(Slave_Addr_Osc,Write_Buffer_Frame,4,I2C_1_MODE_NO_STOP);
    //I2C_1_MasterReadBuf(Slave_Addr_Osc,Read_buf_IRData,0x40,I2C_1_MODE_REPEAT_START);
    
    I2C_1_MasterSendStart(0x60,0);
    I2C_1_MasterWriteByte(0x02);
    I2C_1_MasterWriteByte(0x00);
    I2C_1_MasterWriteByte(0x01);
    I2C_1_MasterWriteByte(0x40);
    I2C_1_MasterSendRestart(0x60,1);
    int y;
    for(y = 0; y <0x41;y++){
     IRData[y] = I2C_1_MasterReadByte(1);   
    }
    I2C_1_MasterSendStop();
    
    //CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */
    for(;;)
    {
        
    }
}

/* [] END OF FILE */
